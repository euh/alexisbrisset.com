AB Study
========

AB Study is a tool to help you remember things _(lessons, songs, poems, talks, etc)_ by heart. From a keyword or more, you have to rewrite the corresponding sentence or paragraph. The order is random without duplicate.

[Demo](http://20c.fr/abstudy/) 
------
Attention, demo uses custom fonts removed in this repository.

How it works
------------

You only have to create a json file, example: 

```json
{
"questions":[
            {
                "question":"π",
                "response":"3.1415926535897932384626433832795"
            },
            {
                "question":"Distance between the Moon and Earth",
                "response":"The distance between the Moon and Earth varies from around 356,400 km to 406,700 km at the extreme perigees and apogees."
            },
			{
				"question":"Sapiosexual",
				"response":"A person sexually attracted to intelligence or the human mind."
			}
    ]
}
```

And you need to edit **index.html** and, or **learn.html** to add your json file in a **option** element, example:

```html
<option value="json/example.json">Example</option>
<option value="json/shakespeare.json">Shakespeare</option>
```

Require
-------

* JQuery _(may be adapted to work without)_
* [Diff Match and Patch library](http://code.google.com/p/google-diff-match-patch/)
* [JQuery Autosize](https://github.com/jackmoore/autosize) _(may be easily removed)_
